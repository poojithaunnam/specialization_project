import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-person2',
  templateUrl: './person2.component.html',
  styleUrls: ['./person2.component.css']
})
export class Person2Component implements OnInit,DoCheck{

  msg:any=[];
  
  constructor(private  data:DataService) 
  {
  
   }
  
  ngOnInit(): void {
  }
  
  ngDoCheck(): void {
    this.msg=this.data.callData();
      
  }
  
  send(msg:any) : void
  {
    this.msg=this.data.dataServe("Veera :" + msg);
  }
}