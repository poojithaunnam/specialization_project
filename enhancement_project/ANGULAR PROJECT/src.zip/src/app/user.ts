export class User{
    id:number=1;
    firstname:string='';
    lastname:string='';
    emailid:string='';
    password:string='';
    confirmpassword:string='';
    DOB:string='';
    mobileno:string='';
    account:string='';

    }